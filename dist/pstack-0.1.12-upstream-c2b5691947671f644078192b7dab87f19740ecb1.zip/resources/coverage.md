# Capability coverage

Upstream 0.15.34 at `519d36aa98955bf680db01bcde5fdfba686dc901`.
Subtree `c2b5691947671f644078192b7dab87f19740ecb1`. Latest checked commit `519d36aa98955bf680db01bcde5fdfba686dc901` on 2026-10-27.
Adaptation status: pending. Host qualification remains incomplete.

All registered skill names remain discoverable. Explicit-only invocation metadata and a body guard are retained; setup keeps its upstream automatic eligibility. Native mode and path-selector metadata are replaced by description and body instructions.

Unchanged means exact copied bytes. Adapted means host-neutral instructions or guarded source content. Unsupported material remains in the repository snapshot only, except clearly marked explanatory entry points.

| Upstream file | Status | Adaptation or limitation | Review |
|---|---|---|---|
| `.cursor-plugin/plugin.json` | unsupported | Source-only supporting material; not loaded or executed by the package. | pending |
| `.gitignore` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `LICENSE` | unchanged | Complete MIT license preserved at repository and package root. | reviewed |
| `README.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | pending |
| `agents/comment-sicko.md` | adapted | Complete comment-review role preserved as a prompt resource; no native agent registration. Uncertain constraints remain until resolved rather than being deleted on ambiguity. | reviewed |
| `agents/poteto-agent.md` | unsupported | Native agent registration unsupported; poteto-mode and no-comments adapt the workflow without a fictitious agent type. | reviewed |
| `assets/logo.png` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `automations/benny/FOR_AGENTS.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/README.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/skills/reproduce-and-fix-issues/SKILL.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/skills/reproduce-and-fix-issues/references/control-adapter.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/skills/reproduce-and-fix-issues/references/feature-map.example.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/skills/reproduce-and-fix-issues/references/verify-existing-fix.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/skills/setup-benny/SKILL.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/skills/triage-issue-reports/SKILL.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/skills/triage-issue-reports/references/routing.example.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/templates/configuration.example.yaml` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/templates/reproduce-automation-prompt.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `automations/benny/templates/triage-automation-prompt.md` | unsupported | Benny external issue automation is outside the skills-only runtime; no automatic external actions. | reviewed |
| `docs/guide/01-setup.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/02-poteto-mode.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/03-understand.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/04-design.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/05-build-and-clean.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/06-verify-and-ship.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | pending |
| `docs/guide/07-overnight.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/08-principles.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/09-make-it-yours.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/10-recipes-and-pitfalls.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/README.md` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/images/design.jpg` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/images/overnight.jpg` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/images/recipes.jpg` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/images/router.jpg` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/images/understanding.jpg` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/guide/images/verification.jpg` | unsupported | Source-only supporting material; not loaded or executed by the package. | reviewed |
| `docs/harness/claude-code.md` | unsupported | Claude Code-specific tool, model, agent, path, and transcript mappings are source-only documentation, not ChatGPT/Codex capabilities. The adapter uses its own host contract and does not package or execute this harness. | reviewed |
| `plugin.json` | unsupported | Upstream root manifest describes Cursor packaging; the adapter owns the ChatGPT/Codex manifests. | pending |
| `skills/architect/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/architect/references/design-red-flags.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/architect/references/rationale-template.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/architect/references/runner-prompt.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/arena/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/automate-me/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/benchmark-checklist/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/blast-radius/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/bro/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/correct/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/create-formal-verification-skill/SKILL.md` | adapted | Portable formal-verification workflow with explicit tool, scope, scratch-isolation, and host registration limits. | pending |
| `skills/create-verification-skill/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/create-verification-skill/references/feature-map-example/README.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/create-verification-skill/references/feature-map-example/create-note.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/create-verification-skill/references/feature-map-example/search.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/figure-it-out/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/how/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/how/references/explainer-prompt.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/how/references/explorer-prompt.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/in-your-own-words/SKILL.md` | adapted | Explicit-only portable workflow with host capability and permission guards. | reviewed |
| `skills/interrogate/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/interrogate/references/code-quality-review.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/interrogate/references/lead-judgment.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/interrogate/references/reviewer-prompt.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/interrogate/references/rubric.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/ketchup-video/SKILL.md` | adapted | Explicit recap with available authorized video tools, outside-repo scratch only, actual artifact/frame evidence and honest fallback to waiting decisions. | reviewed |
| `skills/ketchup/SKILL.md` | adapted | Explicit-only portable workflow with host capability and permission guards. | reviewed |
| `skills/maintain-formal-verification-skill/SKILL.md` | adapted | Formal verification drift review with isolated negative controls, dirty-worktree coverage, evidence-based outcomes and guarded sync advancement. | reviewed |
| `skills/maintain-verification-skill/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/make-bot-ui/SKILL.md` | unsupported | Explanatory entry point only; Grok Bot webhook runtime is not supplied. | reviewed |
| `skills/no-comments/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/poteto-help/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | pending |
| `skills/poteto-help/references/prompting.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/poteto-help/references/recipes.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/poteto-mode/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/poteto-mode/playbooks/authoring-a-skill.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/autonomous-run.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/autopilot-full.md` | unsupported | Explanatory entry point; persistent worker lifecycle and orchestration runtime are not supplied. | reviewed |
| `skills/poteto-mode/playbooks/autopilot-stack.md` | unsupported | Explanatory entry point; persistent worker lifecycle and orchestration runtime are not supplied. | reviewed |
| `skills/poteto-mode/playbooks/babysit.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/bug-fix.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/eval.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/feature.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/hillclimb.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/investigation.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/multi-phase-plan.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/opening-a-pr.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/orchestrate.md` | unsupported | Explanatory entry point; persistent worker lifecycle and orchestration runtime are not supplied. | reviewed |
| `skills/poteto-mode/playbooks/pause-safely.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/perf-issue.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/prototype.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/refactoring.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/runtime-forensics.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/session-pickup.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/shipping.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/trace-forensics.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/visual-parity.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/playbooks/worktree-cleanup.md` | adapted | Workflow stages retained with explicit capability, scope, and evidence gates. | reviewed |
| `skills/poteto-mode/references/bugbot-triage.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/poteto-mode/scripts/bootstrap.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/bun.lock` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/check-plan.mjs` | adapted | Preserve structural checks as an explicit review contract; no Node helper, vendor-model assertion, scheduler, or project-trunk plugin path is assumed. | reviewed |
| `skills/poteto-mode/scripts/check-plan.test.ts` | unsupported | Source-only Node helper tests. The portable plan-validation contract carries supported semantics; no vendored helper is executed or packaged. | reviewed |
| `skills/poteto-mode/scripts/orch/orch.test.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/orch/orch.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/orch/store.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/package.json` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/cli.test.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/cli.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/fakes.test-helper.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/github.test.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/github.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/policy.test.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/policy.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/render.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/tsconfig.json` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/types.compile.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/types.ts` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/watch-pr/watch-pr` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/poteto-mode/scripts/worktree-audit.sh` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/principle-attack-the-premise/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-boundary-discipline/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-build-the-lever/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-encode-lessons-in-structure/SKILL.md` | adapted | Retain prior portable standalone guidance removed by upstream condensation; preserve the complete principle rather than ship a fragment. | reviewed |
| `skills/principle-exhaust-the-design-space/SKILL.md` | adapted | Retain prior portable standalone guidance removed by upstream condensation; preserve the complete principle rather than ship a fragment. | reviewed |
| `skills/principle-experience-first/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-explain-the-number/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-fix-root-causes/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-foundational-thinking/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-guard-the-context-window/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/principle-laziness-protocol/SKILL.md` | adapted | Retain prior portable standalone guidance removed by upstream condensation; preserve the complete principle rather than ship a fragment. | reviewed |
| `skills/principle-make-operations-idempotent/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-migrate-callers-then-delete-legacy-apis/SKILL.md` | adapted | Retain complete standalone guidance removed by upstream condensation; preserve compatibility preconditions and host contract. | reviewed |
| `skills/principle-minimize-reader-load/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-model-the-domain/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-never-block-on-the-human/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/principle-outcome-oriented-execution/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-prove-it-works/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-redesign-from-first-principles/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-separate-before-serializing-shared-state/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-sequence-verifiable-units/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-subtract-before-you-add/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-test-behavior-not-implementation/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/principle-type-system-discipline/SKILL.md` | adapted | Retain complete standalone guidance removed by upstream condensation; preserve compatibility preconditions and host contract. | reviewed |
| `skills/recall/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/reflect/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/reflect/references/divergent-reviewer.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/reflect/references/judgment-reviewer.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/reflect/references/synthesizer.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/reflect/references/tooling-reviewer.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/setup-pstack/SKILL.md` | adapted | Preserve all seven setup stages, four budget choices, and 17 role entries; use observed host model controls and authorized project persistence rather than vendor defaults or a global rule. | reviewed |
| `skills/sharpen/SKILL.md` | adapted | Explicit prompt rewriting with four expert recommendations, preserved user constraints and choices, and no underlying task execution. | reviewed |
| `skills/show-me-your-work/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/show-me-your-work/references/decision-log-template.tsv` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/show-me-your-work/scripts/log.sh` | unsupported | Host-specific helper retained only as source. No helper is executed or distributed in the ZIP. | reviewed |
| `skills/statechart/SKILL.md` | adapted | Portable statechart/model review with explicit checker, renderer and replay evidence; bundled Node generators and TLC integration remain unsupported. | pending |
| `skills/statechart/references/render.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/backends/cfg.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/backends/mermaid.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/backends/plain-text.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/backends/report.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/frontends/config.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/frontends/dot.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/frontends/marks.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/frontends/messages.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/frontends/spec.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/frontends/trace.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/frontends/value.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/frontends/verdict.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/frontends/view.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/ir.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/package.json` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/passes/annotate.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/passes/label.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/passes/lift.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/passes/loop-check.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/passes/paths.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/passes/reach.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/passes/region-check.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/passes/regions.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/pipeline.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/run.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/statechart` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/statechart.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/ConfigOracle.java` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/chart.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/charts/Braces.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/charts/Escapes.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/charts/Phases.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/cli.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/config-fuzz.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Counter/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Counter/Counter.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Counter/Counter.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Counter/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Counter/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Counter/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Counter/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Counter/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/CounterAction.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/CounterAction.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterAction/verdict-3.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/CounterDeadlock.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/CounterDeadlock.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterDeadlock/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/CounterFan.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/CounterFan.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterFan/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/ChartRun.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/CounterGuard.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/CounterGuard.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterGuard/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/CounterInitPast.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/CounterInitPast.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPast/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPastHolds/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPastHolds/CounterInitPastHolds.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPastHolds/CounterInitPastHolds.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPastHolds/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPastHolds/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPastHolds/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPastHolds/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInitPastHolds/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/CounterInstance.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/CounterInstance.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/CounterSteps.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterInstance/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/CounterJump.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/CounterJump.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterJump/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterLoop/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterLoop/CounterLoop.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterLoop/CounterLoop.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterLoop/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterLoop/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterLoop/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterLoop/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterLoop/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterLoop/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/CounterOrder.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/CounterOrder.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterOrder/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/CounterRules.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/CounterRules.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/Moves.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/verdict-3.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/verdict-3.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterRules/verdict-4.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/CounterStart.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/CounterStart.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStart/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStop/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStop/CounterStop.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStop/CounterStop.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStop/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStop/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStop/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStop/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterStop/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/CounterTie.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/CounterTie.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/verdict-3.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/verdict-3.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTie/verdict-4.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/CounterTieInGraph.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/CounterTieInGraph.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterTieInGraph/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/CounterView.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/CounterView.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/verdict-3.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/verdict-3.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/verdict-4.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/CounterView/view.mjs` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/DieHard.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/DieHard.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/DieHard/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/FirstRule.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/FirstRule.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/verdict-3.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/verdict-3.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/verdict-4.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/FirstRule/verdict-4.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/HiddenClock/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/HiddenClock/HiddenClock.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/HiddenClock/HiddenClock.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/HiddenClock/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/HiddenClock/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/HiddenClock/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/HiddenClock/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/HiddenClock/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/HiddenClock/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Login/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Login/Login.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Login/Login.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Login/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Login/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Login/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Login/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Login/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Login/view.mjs` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginGuarded/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginGuarded/LoginGuarded.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginGuarded/LoginGuarded.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginGuarded/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginGuarded/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginGuarded/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginGuarded/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginGuarded/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginGuarded/view.mjs` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/LoginParallel.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/LoginParallel.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/LoginParallel/view.mjs` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/MediaPlayer.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/MediaPlayer.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayer/view.mjs` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerFixed/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerFixed/MediaPlayerFixed.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerFixed/MediaPlayerFixed.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerFixed/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerFixed/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerFixed/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerFixed/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerFixed/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerFixed/view.mjs` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/MediaPlayer.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/MediaPlayerProps.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/MediaPlayerProps.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/verdict-3.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/verdict-4.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/verdict-4.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/verdict-5.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/verdict-5.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/verdict-6.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/MediaPlayerProps/view.mjs` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/PickWorker/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/PickWorker/PickWorker.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/PickWorker/PickWorker.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/PickWorker/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/PickWorker/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/PickWorker/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/PickWorker/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/PickWorker/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/Shadow.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/Shadow.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/ShadowLib.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/ShadowSub.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/Shadow/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/SpacedNames.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/SpacedNames.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/SpacedNames/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/TwoPhase.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/TwoPhase.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhase/view.mjs` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhaseFixed/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhaseFixed/TwoPhaseFixed.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhaseFixed/TwoPhaseFixed.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhaseFixed/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhaseFixed/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhaseFixed/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhaseFixed/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhaseFixed/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TwoPhaseFixed/view.mjs` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/ChartRun.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/TypeGuard.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/TypeGuard.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/TypeGuard/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/ChartRun.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/UserNoDeadlock.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/UserNoDeadlock.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/chart.mmd` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/graph.dot` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/report.md` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/verdict-1.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/verdict-1.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/verdict-2.exit` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/corpus/UserNoDeadlock/verdict-2.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/differential.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/grid/Grid.cfg` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/grid/Grid.tla` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/grid/sany.out` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/java.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/labels.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/messages.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/pipeline.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/plain-tlc.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/render.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/tlc-out.test.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/test/tlc.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/tsconfig.json` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/statechart/scripts/worker.ts` | unsupported | Unclassified new upstream file; review required. | pending |
| `skills/swarm/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/tdd/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/teach/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/technical-writing/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/typescript-best-practices/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/typescript-best-practices/references/patterns.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/unslop/SKILL.md` | adapted | Upstream body retained; invocation and host/permission guards added. | reviewed |
| `skills/why/SKILL.md` | adapted | Explicit host workflow adaptation; source identity and invocation intent retained. | reviewed |
| `skills/why/references/epistemics.md` | unchanged | Portable reference contract retained byte-for-byte and invoked by its workflow. | reviewed |
| `skills/why/references/investigator-prompt.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/source-playbook.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/sources/code-archaeology.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/sources/databricks.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/sources/datadog.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/sources/incident-postmortem.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/sources/linear.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/sources/notion.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/sources/sentry.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/sources/slack.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
| `skills/why/references/synthesizer-prompt.md` | adapted | Full reference retained with capability/permission preface and narrow host-path or runner corrections. | reviewed |
